/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import pojo.Rute;

/**
 *
 * @author Kmsmr
 */
public class RuteBeanTest {
    
    public RuteBeanTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of loadRutes method, of class RuteBean.
     */
    @Test
    public void testLoadRutes() {
        System.out.println("loadRutes");
        RuteBean instance = new RuteBean();
        instance.loadRutes();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRuteList method, of class RuteBean.
     */
    @Test
    public void testGetRuteList() {
        System.out.println("getRuteList");
        RuteBean instance = new RuteBean();
        List<Rute> expResult = null;
        List<Rute> result = instance.getRuteList();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSelectedRute method, of class RuteBean.
     */
    @Test
    public void testGetSelectedRute() {
        System.out.println("getSelectedRute");
        RuteBean instance = new RuteBean();
        Rute expResult = null;
        Rute result = instance.getSelectedRute();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNewRute method, of class RuteBean.
     */
    @Test
    public void testGetNewRute() {
        System.out.println("getNewRute");
        RuteBean instance = new RuteBean();
        Rute expResult = null;
        Rute result = instance.getNewRute();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isEditFormVisible method, of class RuteBean.
     */
    @Test
    public void testIsEditFormVisible() {
        System.out.println("isEditFormVisible");
        RuteBean instance = new RuteBean();
        boolean expResult = false;
        boolean result = instance.isEditFormVisible();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isAddFormVisible method, of class RuteBean.
     */
    @Test
    public void testIsAddFormVisible() {
        System.out.println("isAddFormVisible");
        RuteBean instance = new RuteBean();
        boolean expResult = false;
        boolean result = instance.isAddFormVisible();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addRute method, of class RuteBean.
     */
    @Test
    public void testAddRute() {
        System.out.println("addRute");
        RuteBean instance = new RuteBean();
        instance.addRute();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of edit method, of class RuteBean.
     */
    @Test
    public void testEdit() {
        System.out.println("edit");
        Rute rute = null;
        RuteBean instance = new RuteBean();
        instance.edit(rute);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of update method, of class RuteBean.
     */
    @Test
    public void testUpdate() {
        System.out.println("update");
        RuteBean instance = new RuteBean();
        instance.update();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of delete method, of class RuteBean.
     */
    @Test
    public void testDelete() {
        System.out.println("delete");
        Rute rute = null;
        RuteBean instance = new RuteBean();
        instance.delete(rute);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of resetNewRute method, of class RuteBean.
     */
    @Test
    public void testResetNewRute() {
        System.out.println("resetNewRute");
        RuteBean instance = new RuteBean();
        instance.resetNewRute();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of resetSelectedRute method, of class RuteBean.
     */
    @Test
    public void testResetSelectedRute() {
        System.out.println("resetSelectedRute");
        RuteBean instance = new RuteBean();
        instance.resetSelectedRute();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRuteById method, of class RuteBean.
     */
    @Test
    public void testGetRuteById() {
        System.out.println("getRuteById");
        String idRute = "";
        RuteBean instance = new RuteBean();
        Rute expResult = null;
        Rute result = instance.getRuteById(idRute);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
