/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import pojo.Fleet;

/**
 *
 * @author Kmsmr
 */
public class SPJBeanTest {
    
    public SPJBeanTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of loadFleet method, of class SPJBean.
     */
    @Test
    public void testLoadFleet() {
        System.out.println("loadFleet");
        SPJBean instance = new SPJBean();
        instance.loadFleet();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFleetList method, of class SPJBean.
     */
    @Test
    public void testGetFleetList() {
        System.out.println("getFleetList");
        SPJBean instance = new SPJBean();
        List<Fleet> expResult = null;
        List<Fleet> result = instance.getFleetList();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSelectedFleet method, of class SPJBean.
     */
    @Test
    public void testGetSelectedFleet() {
        System.out.println("getSelectedFleet");
        SPJBean instance = new SPJBean();
        Fleet expResult = null;
        Fleet result = instance.getSelectedFleet();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNewFleet method, of class SPJBean.
     */
    @Test
    public void testGetNewFleet() {
        System.out.println("getNewFleet");
        SPJBean instance = new SPJBean();
        Fleet expResult = null;
        Fleet result = instance.getNewFleet();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addSPJ method, of class SPJBean.
     */
    @Test
    public void testAddSPJ() {
        System.out.println("addSPJ");
        SPJBean instance = new SPJBean();
        instance.addSPJ();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of update method, of class SPJBean.
     */
    @Test
    public void testUpdate() {
        System.out.println("update");
        SPJBean instance = new SPJBean();
        instance.update();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of delete method, of class SPJBean.
     */
    @Test
    public void testDelete() {
        System.out.println("delete");
        Fleet fleet = null;
        SPJBean instance = new SPJBean();
        instance.delete(fleet);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of resetNewFleet method, of class SPJBean.
     */
    @Test
    public void testResetNewFleet() {
        System.out.println("resetNewFleet");
        SPJBean instance = new SPJBean();
        instance.resetNewFleet();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of resetSelectedFleet method, of class SPJBean.
     */
    @Test
    public void testResetSelectedFleet() {
        System.out.println("resetSelectedFleet");
        SPJBean instance = new SPJBean();
        instance.resetSelectedFleet();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
