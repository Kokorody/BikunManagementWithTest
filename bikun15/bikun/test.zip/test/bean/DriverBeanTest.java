/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.List;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import pojo.Driver;

/**
 *
 * @author Kmsmr
 */
public class DriverBeanTest {
    
    public DriverBeanTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of loadDrivers method, of class DriverBean.
     */
    @Test
    public void testLoadDrivers() {
        System.out.println("loadDrivers");
        DriverBean instance = new DriverBean();
        instance.loadDrivers();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loadAvailableDriver method, of class DriverBean.
     */
    @Test
    public void testLoadAvailableDriver() {
        System.out.println("loadAvailableDriver");
        DriverBean instance = new DriverBean();
        instance.loadAvailableDriver();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAvailableDrivers method, of class DriverBean.
     */
    @Test
    public void testGetAvailableDrivers() {
        System.out.println("getAvailableDrivers");
        DriverBean instance = new DriverBean();
        List<Driver> expResult = null;
        List<Driver> result = instance.getAvailableDrivers();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDriverById method, of class DriverBean.
     */
    @Test
    public void testGetDriverById() {
        System.out.println("getDriverById");
        int idDriver = 0;
        DriverBean instance = new DriverBean();
        Driver expResult = null;
        Driver result = instance.getDriverById(idDriver);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDriverList method, of class DriverBean.
     */
    @Test
    public void testGetDriverList() {
        System.out.println("getDriverList");
        DriverBean instance = new DriverBean();
        List<Driver> expResult = null;
        List<Driver> result = instance.getDriverList();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSelectedDriver method, of class DriverBean.
     */
    @Test
    public void testGetSelectedDriver() {
        System.out.println("getSelectedDriver");
        DriverBean instance = new DriverBean();
        Driver expResult = null;
        Driver result = instance.getSelectedDriver();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNewDriver method, of class DriverBean.
     */
    @Test
    public void testGetNewDriver() {
        System.out.println("getNewDriver");
        DriverBean instance = new DriverBean();
        Driver expResult = null;
        Driver result = instance.getNewDriver();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isEditFormVisible method, of class DriverBean.
     */
    @Test
    public void testIsEditFormVisible() {
        System.out.println("isEditFormVisible");
        DriverBean instance = new DriverBean();
        boolean expResult = false;
        boolean result = instance.isEditFormVisible();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isAddFormVisible method, of class DriverBean.
     */
    @Test
    public void testIsAddFormVisible() {
        System.out.println("isAddFormVisible");
        DriverBean instance = new DriverBean();
        boolean expResult = false;
        boolean result = instance.isAddFormVisible();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSpjBean method, of class DriverBean.
     */
    @Test
    public void testSetSpjBean() {
        System.out.println("setSpjBean");
        SPJBean spjBean = null;
        DriverBean instance = new DriverBean();
        instance.setSpjBean(spjBean);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addDriver method, of class DriverBean.
     */
    @Test
    public void testAddDriver() {
        System.out.println("addDriver");
        DriverBean instance = new DriverBean();
        instance.addDriver();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isNoSimValid method, of class DriverBean.
     */
    @Test
    public void testIsNoSimValid() {
        System.out.println("isNoSimValid");
        String noSim = "";
        DriverBean instance = new DriverBean();
        boolean expResult = false;
        boolean result = instance.isNoSimValid(noSim);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of edit method, of class DriverBean.
     */
    @Test
    public void testEdit() {
        System.out.println("edit");
        Driver driver = null;
        DriverBean instance = new DriverBean();
        instance.edit(driver);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of update method, of class DriverBean.
     */
    @Test
    public void testUpdate() {
        System.out.println("update");
        DriverBean instance = new DriverBean();
        instance.update();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of delete method, of class DriverBean.
     */
    @Test
    public void testDelete() {
        System.out.println("delete");
        Driver driver = null;
        DriverBean instance = new DriverBean();
        instance.delete(driver);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of resetNewDriver method, of class DriverBean.
     */
    @Test
    public void testResetNewDriver() {
        System.out.println("resetNewDriver");
        DriverBean instance = new DriverBean();
        instance.resetNewDriver();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of resetSelectedDriver method, of class DriverBean.
     */
    @Test
    public void testResetSelectedDriver() {
        System.out.println("resetSelectedDriver");
        DriverBean instance = new DriverBean();
        instance.resetSelectedDriver();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of noSimValidator method, of class DriverBean.
     */
    @Test
    public void testNoSimValidator() {
        System.out.println("noSimValidator");
        FacesContext context = null;
        UIComponent component = null;
        Object value = null;
        DriverBean instance = new DriverBean();
        instance.noSimValidator(context, component, value);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
