import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.Query;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import pojo.Admin;
import DAO.AdminDAO;
import java.util.Collections;

public class AdminDAOTest {
    @InjectMocks
    private AdminDAO adminDAO; // DAO to test

    @Mock
    private Session session; // Mock session

    @Mock
    private Transaction transaction; // Mock transaction

    @Mock
    private Query query; // Mock query

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        
        // Mock the session behavior
        when(session.beginTransaction()).thenReturn(transaction);
        when(session.createQuery(anyString())).thenReturn(query); // Mock the creation of queries
    }

    @Test
    public void testValidate_Success() {
        Admin admin = new Admin();
        admin.setUsername("admin");
        admin.setPassword("password");

        // Set up the query mock to return the admin
        when(query.list()).thenReturn(Collections.singletonList(admin));
        when(query.setParameter(anyString(), any())).thenReturn(query); // Mock the setParameter call

        // Call the validate method
        boolean result = adminDAO.validate("admin", "password");

        // Assertions
        assertTrue(result); // Should return true
        verify(session).close(); // Ensure the session is closed
    }

    @Test
    public void testValidate_Failure() {
        // Mock behavior to return no Admin found
        when(query.list()).thenReturn(Collections.emptyList());
        when(query.setParameter(anyString(), any())).thenReturn(query); // Mock the setParameter call

        boolean result = adminDAO.validate("admin", "wrongpassword");

        assertFalse(result); // Should return false
        verify(session).close(); // Ensure the session is closed
    }

    @Test
    public void testIsUsernameExists() {
        // Mock the behavior to return an existing admin
        when(query.list()).thenReturn(Collections.singletonList(new Admin())); // Return a list with one Admin
        when(query.setParameter(anyString(), any())).thenReturn(query); // Mock the setParameter call

        boolean exists = adminDAO.isUsernameExists("admin");

        assertTrue(exists); // Should return true
        verify(session).close(); // Ensure the session is closed
    }

    @Test
    public void testIsUsernameNotExists() {
        // Mocking that the username does not exist
        when(query.list()).thenReturn(Collections.emptyList()); // Return empty list
        when(query.setParameter(anyString(), any())).thenReturn(query); // Mock the setParameter call

        boolean exists = adminDAO.isUsernameExists("nonexistent");

        assertFalse(exists); // Should return false
        verify(session).close(); // Ensure the session is closed
    }
}
