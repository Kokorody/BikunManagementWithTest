package DAO;

import DAO.SPJDAO;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.Query;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import pojo.Fleet;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

public class SPJDAOTest {

    @Mock
    private SessionFactory mockSessionFactory;

    @Mock
    private Session mockSession;

    @Mock
    private Transaction mockTransaction;

    @InjectMocks
    private SPJDAO spjDAO;
    
    @Mock
    private Query mockQuery; // Declare mockQuery as a mock

    private Fleet mockFleet;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        
        // Mock the behavior of SessionFactory and Session
        when(mockSessionFactory.openSession()).thenReturn(mockSession);
        when(mockSession.beginTransaction()).thenReturn(mockTransaction);

        // Initialize a mock Fleet object
        mockFleet = new Fleet();
        mockFleet.setIdFleet(1);
        
        
    }

    // Test for getAllFleets()
@Test
public void testGetAllFleets() {
    List<Fleet> mockFleetList = new ArrayList<>();
    mockFleetList.add(mockFleet);

    // Create a mock Query object
    Query mockQuery = mock(Query.class);

    // Mock the behavior of the query creation
    when(mockSession.createQuery("FROM Fleet")).thenReturn(mockQuery);
    when(mockQuery.list()).thenReturn(mockFleetList); // Mock the list() method to return the mockFleetList

    List<Fleet> result = spjDAO.getAllFleets();

    // Verify the session and query interactions
    verify(mockSession, times(1)).createQuery("FROM Fleet");
    verify(mockQuery, times(1)).list(); // Verify that the list method was called on the mockQuery
    verify(mockSession, times(1)).close();

    // Assert that the retrieved list matches the mock data
    assertEquals(mockFleetList, result);
}

    // Test for addSPJ(Fleet fleet)
    @Test
    public void testAddSPJ() {
//        doNothing().when(mockSession).save(mockFleet);

        // Call the method
        spjDAO.addSPJ(mockFleet);

        // Verify that the save and transaction commit were called
        verify(mockSession, times(1)).save(mockFleet);
        verify(mockTransaction, times(1)).commit();
        verify(mockSession, times(1)).close();
    }

    // Test for updateSPJ(Fleet fleet)
    @Test
    public void testUpdateSPJ() {
        doNothing().when(mockSession).update(mockFleet);

        // Call the method
        spjDAO.updateSPJ(mockFleet);

        // Verify that the update and transaction commit were called
        verify(mockSession, times(1)).update(mockFleet);
        verify(mockTransaction, times(1)).commit();
        verify(mockSession, times(1)).close();
    }

    // Test for deleteSPJ(Fleet fleet)
    @Test
    public void testDeleteSPJ() {
        doNothing().when(mockSession).delete(mockFleet);

        // Call the method
        spjDAO.deleteSPJ(mockFleet);

        // Verify that the delete and transaction commit were called
        verify(mockSession, times(1)).delete(mockFleet);
        verify(mockTransaction, times(1)).commit();
        verify(mockSession, times(1)).close();
    }

    // Test for updateBusStatus(int id_bus, String status)
    @Test
    public void testUpdateBusStatus() {
        int idBus = 10;
        String status = "Active";

        // Mock the update query
        when(mockSession.createQuery("UPDATE Bus SET status = :status WHERE id_bus = :id_bus"))
                .thenReturn(mockQuery);

        // Mock the behavior of the query parameters and execution
        when(mockQuery.setParameter("status", status)).thenReturn(mockQuery);
        when(mockQuery.setParameter("id_bus", idBus)).thenReturn(mockQuery);
        when(mockQuery.executeUpdate()).thenReturn(1); // Mock the executeUpdate() method

        // Call the method
        spjDAO.updateBusStatus(idBus, status);

        // Verify that the query was created and executed
        verify(mockSession, times(1)).createQuery("UPDATE Bus SET status = :status WHERE id_bus = :id_bus");
        verify(mockQuery, times(1)).setParameter("status", status);
        verify(mockQuery, times(1)).setParameter("id_bus", idBus);
        verify(mockQuery, times(1)).executeUpdate();

        // Verify transaction and session closure
        verify(mockTransaction, times(1)).commit();
        verify(mockSession, times(1)).close();
    }
}

