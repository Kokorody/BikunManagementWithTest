package DAO;

import DAO.RuteDAO;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.Query;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import pojo.Rute;

import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

public class RuteDAOTest {

    @InjectMocks
    private RuteDAO ruteDAO;

    @Mock
    private SessionFactory sessionFactory;

    @Mock
    private Session session;

    @Mock
    private Transaction transaction;

    @Mock
    private Query query;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        // Mock the session behavior
        when(sessionFactory.openSession()).thenReturn(session);  // Mock session factory to return session
        when(session.beginTransaction()).thenReturn(transaction); // Mock transaction
        when(session.createQuery(anyString())).thenReturn(query); // Mock the creation of queries
    }

    @Test
    public void testGetAllRutes() {
        Rute rute = new Rute(); // Create a Rute object (add attributes if needed)

        when(query.list()).thenReturn(Collections.singletonList(rute)); // Mock query result

        List<Rute> rutes = ruteDAO.getAllRutes();

        assertNotNull(rutes);
        assertEquals(1, rutes.size());
        // You can add assertions for specific Rute attributes if needed
    }

    @Test
    public void testAddRute() {
        Rute rute = new Rute(); // Create a Rute object (add attributes if needed)

        // Mock the behavior of session.save (returns the ID or similar)
        when(session.save(rute)).thenReturn(rute);

        ruteDAO.addRute(rute);

        verify(session).save(rute);
        verify(transaction).commit();
    }

    @Test
    public void testDeleteRute() {
        Rute rute = new Rute(); // Create a Rute object (add attributes if needed)

        // No return value needed for session.delete
        doNothing().when(session).delete(rute);

        ruteDAO.deleteRute(rute);

        verify(session).delete(rute);
        verify(transaction).commit();
    }

    @Test
    public void testUpdateRute() {
        Rute rute = new Rute(); // Create a Rute object (add attributes if needed)
        rute.setIdRute("R001"); // Ensure the rute has an ID for testing update

        // No return value needed for session.update
        //doNothing().when(session).merge(rute);

        ruteDAO.updateRute(rute);

        verify(session).merge(rute);
        verify(transaction).commit();
    }

    @Test
    public void testFindById() {
        Rute rute = new Rute(); // Create a Rute object (add attributes if needed)
        rute.setIdRute("R001"); // Ensure it has an ID for testing

        // Mock session.get to return the rute
        when(session.get(Rute.class, "R001")).thenReturn(rute);

        Rute result = ruteDAO.findById("R001");

        assertNotNull(result);
        assertEquals("R001", result.getIdRute());
        // Add more assertions as needed for Rute attributes
    }
}
