package DAO;
import DAO.DriverDAO;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.Query;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import pojo.Driver;

import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

public class DriverDAOTest {

    @InjectMocks
    private DriverDAO driverDAO;

    @Mock
    private SessionFactory sessionFactory;

    @Mock
    private Session session;

    @Mock
    private Transaction transaction;

    @Mock
    private Query query;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        
        // Mock the session behavior
        when(sessionFactory.openSession()).thenReturn(session);  // Mock session factory to return session
        when(session.beginTransaction()).thenReturn(transaction); // Mock transaction
        when(session.createQuery(anyString())).thenReturn(query); // Mock the creation of queries
    }

    @Test
    public void testGetAllDrivers() {
        Driver driver = new Driver(); // Create a Driver object (add attributes if needed)

        when(query.list()).thenReturn(Collections.singletonList(driver)); // Mock query result

        List<Driver> drivers = driverDAO.getAllDrivers();

        assertNotNull(drivers);
        assertEquals(1, drivers.size());
        // You can add assertions for specific Driver attributes if needed
    }

    @Test
    public void testAddDriver() {
        Driver driver = new Driver(); // Create a Driver object (add attributes if needed)

        // Mock the behavior of session.save (returns the ID or similar)
        when(session.save(driver)).thenReturn(driver);

        driverDAO.addDriver(driver);

        verify(session).save(driver);
        verify(transaction).commit();
    }

    @Test
    public void testDeleteDriver() {
        Driver driver = new Driver(); // Create a Driver object (add attributes if needed)

        // No return value needed for session.delete
        doNothing().when(session).delete(driver);

        driverDAO.deleteDriver(driver);

        verify(session).delete(driver);
        verify(transaction).commit();
    }

    @Test
    public void testUpdateDriver() {
        Driver driver = new Driver(); // Create a Driver object (add attributes if needed)
        driver.setIdDriver(1); // Ensure the driver has an ID for testing update

        // No return value needed for session.update
        doNothing().when(session).update(driver);

        driverDAO.updateDriver(driver);

        verify(session).update(driver);
        verify(transaction).commit();
    }

    @Test
    public void testFindByName() {
        Driver driver = new Driver(); // Create a Driver object with a name
        driver.setIdDriver(1); // Ensure it has an ID for testing

        // Mock the query to return the driver based on name
        when(session.createQuery("FROM Driver WHERE namaDriver = :name")
                .setParameter("name", "John Doe")
                .uniqueResult()).thenReturn(driver);

        Driver result = driverDAO.findByName("John Doe");

        assertNotNull(result);
        assertEquals(Integer.valueOf(1), result.getIdDriver());
        // Add more assertions as needed for Driver attributes
    }

    @Test
    public void testGetAvailableDrivers() {
        Driver driver = new Driver(); // Create a Driver object (add attributes if needed)

        when(query.list()).thenReturn(Collections.singletonList(driver));

        List<Driver> availableDrivers = driverDAO.getAvailableDrivers();

        assertNotNull(availableDrivers);
        assertEquals(1, availableDrivers.size());
        // You can add assertions for specific Driver attributes if needed
    }
}
