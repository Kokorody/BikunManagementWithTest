import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import bean.LoginBean;
import DAO.AdminDAO;

public class LoginBeanTest {

    @InjectMocks
    private LoginBean loginBean;

    @Mock
    private AdminDAO adminDAO;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testValidateUsername_EmptyUsername() {
        loginBean.setUsername("");
        loginBean.validateUsername();
        assertEquals("Username cannot be empty", loginBean.getMessage());
    }

    @Test
    public void testValidateUsername_NonExistingUsername() {
        when(adminDAO.isUsernameExists(anyString())).thenReturn(false);

        loginBean.setUsername("nonexistent");
        loginBean.validateUsername();

        assertEquals("Username does not exist", loginBean.getMessage());
    }

    @Test
    public void testValidateUsername_ExistingUsername() {
        when(adminDAO.isUsernameExists(anyString())).thenReturn(true);

        loginBean.setUsername("admin");
        loginBean.validateUsername();

        assertEquals("", loginBean.getMessage());
    }

    @Test
    public void testValidatePassword_EmptyPassword() {
        loginBean.setPassword("");
        loginBean.validatePassword();
        assertEquals("Password cannot be empty", loginBean.getMessage());
    }

    @Test
    public void testValidatePassword_IncorrectPassword() {
        when(adminDAO.isPasswordCorrect(anyString(), anyString())).thenReturn(false);

        loginBean.setUsername("admin");
        loginBean.setPassword("wrongpassword");
        loginBean.validatePassword();

        assertEquals("Incorrect password", loginBean.getMessage());
    }

    @Test
    public void testValidatePassword_CorrectPassword() {
        when(adminDAO.isPasswordCorrect(anyString(), anyString())).thenReturn(true);

        loginBean.setUsername("admin");
        loginBean.setPassword("password");
        loginBean.validatePassword();

        assertEquals("", loginBean.getMessage());
    }

    @Test
    public void testLogin_Success() {
        when(adminDAO.validate(anyString(), anyString())).thenReturn(true);

        loginBean.setUsername("admin");
        loginBean.setPassword("password");
        String result = loginBean.login();

        assertEquals("success", result);
        assertEquals("", loginBean.getMessage());
    }

    @Test
    public void testLogin_Failure() {
        when(adminDAO.validate(anyString(), anyString())).thenReturn(false);

        loginBean.setUsername("admin");
        loginBean.setPassword("wrongpassword");
        String result = loginBean.login();

        assertEquals("error", result);
        assertEquals("Invalid Username or Password", loginBean.getMessage());
    }
    
//    @Test
//    public void testLogin_SpecialChar() {
//        
//    }
}
