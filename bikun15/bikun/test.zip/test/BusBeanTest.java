import bean.BusBean;
import DAO.BusDAO;
import helper.FacesContextHelper;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import pojo.Bus;

import javax.faces.application.FacesMessage;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

public class BusBeanTest {

    private BusBean busBean;
    private BusDAO busDAOMock;
    private FacesContextHelper facesContextHelperMock;

    @Before
    public void setUp() {
        // Create mock instances of BusDAO and FacesContextHelper
        busDAOMock = mock(BusDAO.class);
        facesContextHelperMock = mock(FacesContextHelper.class);

        // Create an instance of BusBean with the mocked BusDAO
        busBean = new BusBean(busDAOMock);
        busBean.setFacesContextHelper(facesContextHelperMock);  // Inject the mock FacesContextHelper
    }

    @Test
    public void testAddBus_Successful() {
        // Arrange
        Bus newBus = new Bus();
        newBus.setNoBody("ABC-1234");
        newBus.setPlatNomor("B 1234 CD");
        newBus.setTipeBus("MiniBus");
        newBus.setStatus("deploy");

        // Act
        busBean.getNewBus().setNoBody("ABC-1234");
        busBean.getNewBus().setPlatNomor("B 1234 CD");
        busBean.getNewBus().setTipeBus("MiniBus");
        busBean.getNewBus().setStatus("deploy");
        busBean.addBus();

        // Assert
        verify(busDAOMock).addBus(any(Bus.class));  // Verify that the addBus method is called
        ArgumentCaptor<FacesMessage> messageCaptor = ArgumentCaptor.forClass(FacesMessage.class);
        verify(facesContextHelperMock).addMessage(eq(null), messageCaptor.capture());

        FacesMessage message = messageCaptor.getValue();
        assertEquals(FacesMessage.SEVERITY_INFO, message.getSeverity());
        assertEquals("Bus added successfully!", message.getSummary());
    }

    @Test
    public void testAddBus_InvalidData() {
        // Arrange
        // Invalidate the bus by setting a wrong format for No Body
        busBean.getNewBus().setNoBody("INVALID");

        // Act
        busBean.addBus();

        // Assert
        verify(busDAOMock, never()).addBus(any(Bus.class)); // DAO addBus should never be called on validation failure
        verify(facesContextHelperMock, times(1)).addMessage(eq("noBody"),
            any(FacesMessage.class)); // Error message should be added
    }

    @Test
    public void testUpdateBus_Successful() {
        // Arrange
        Bus bus = new Bus();
        bus.setNoBody("XYZ-5678");
        busBean.edit(bus);

        // Mock the updateBus method (void method)
        doNothing().when(busDAOMock).updateBus(any(Bus.class));

        // Act
        busBean.update();

        // Assert
        verify(busDAOMock, times(1)).updateBus(bus); // Verify DAO's updateBus method is called
        ArgumentCaptor<FacesMessage> messageCaptor = ArgumentCaptor.forClass(FacesMessage.class);
        verify(facesContextHelperMock, times(1)).addMessage(eq(null), messageCaptor.capture());

        FacesMessage message = messageCaptor.getValue();
        assertEquals(FacesMessage.SEVERITY_INFO, message.getSeverity());
        assertEquals("Bus updated successfully!", message.getSummary());
    }

    @Test
    public void testDeleteBus_Successful() {
        // Arrange
        Bus bus = new Bus();
        bus.setNoBody("ABC-1234");

        // Mock the deleteBus method (void method)
        doNothing().when(busDAOMock).deleteBus(any(Bus.class));

        // Act
        busBean.delete(bus);

        // Assert
        verify(busDAOMock, times(1)).deleteBus(bus); // Verify DAO's deleteBus method is called
        ArgumentCaptor<FacesMessage> messageCaptor = ArgumentCaptor.forClass(FacesMessage.class);
        verify(facesContextHelperMock, times(1)).addMessage(eq(null), messageCaptor.capture());

        FacesMessage message = messageCaptor.getValue();
        assertEquals(FacesMessage.SEVERITY_INFO, message.getSeverity());
        assertEquals("Bus deleted successfully!", message.getSummary());
    }

@Test
public void testLoadBuses() {
    // Arrange
    List<Bus> mockBusList = new ArrayList<>();
    mockBusList.add(new Bus()); // Add a dummy bus to the list

    // Mocking busDAO.getAllBuses() to return the buses
    when(busDAOMock.getAllBuses()).thenReturn(mockBusList); // Do NOT reset this

    // Act - Call the method
    busBean.loadBuses();

    // Assert
    verify(busDAOMock, times(2)).getAllBuses(); // Ensure DAO method is called exactly once
    assertEquals(1, busBean.getBusList().size()); // Ensure the bus list is updated
}



@Test
public void testLoadAvailableBuses() {
    // Arrange
    List<Bus> availableBuses = new ArrayList<>();
    availableBuses.add(new Bus()); // Add a dummy bus to the list

    // Mocking busDAO.getAvailableBuses() to return the available buses
    when(busDAOMock.getAvailableBuses()).thenReturn(availableBuses);

    // Act - Call the method just once
    busBean.loadAvailableBuses();

    // Assert
    verify(busDAOMock, times(2)).getAvailableBuses(); // Ensure DAO method is called exactly once
    assertEquals(1, busBean.getAvailableBuses().size()); // Ensure the available bus list is updated
}



}
