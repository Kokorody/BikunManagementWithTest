import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.Query;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import pojo.Bus;
import DAO.BusDAO;

import java.util.Collections;
import java.util.List;

public class BusDAOTest {

    @InjectMocks
    private BusDAO busDAO;

    @Mock
    private SessionFactory sessionFactory;

    @Mock
    private Session session;

    @Mock
    private Transaction transaction;

    @Mock
    private Query query;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        
        // Mock the session behavior
        when(sessionFactory.openSession()).thenReturn(session);  // Mock session factory to return session
        when(session.beginTransaction()).thenReturn(transaction); // Mock transaction
        when(session.createQuery(anyString())).thenReturn(query); // Mock the creation of queries
    }

    @Test
    public void testGetAllBuses() {
        Bus bus = new Bus("NB123", "PLATE123", "TypeA", "Owner1", "depot");

        when(query.list()).thenReturn(Collections.singletonList(bus)); // Mock query result

        List<Bus> buses = busDAO.getAllBuses();

        assertNotNull(buses);
        assertEquals(1, buses.size());
        assertEquals("NB123", buses.get(0).getNoBody());
        assertEquals("PLATE123", buses.get(0).getPlatNomor());
        assertEquals("TypeA", buses.get(0).getTipeBus());
        assertEquals("Owner1", buses.get(0).getPemilik());
        assertEquals("depot", buses.get(0).getStatus());
    }

    @Test
    public void testAddBus() {
        Bus bus = new Bus("NB124", "PLATE124", "TypeB", "Owner2", "active");

        // Mock the behavior of session.save (returns the ID or similar)
        when(session.save(bus)).thenReturn(bus.getIdBus());

        busDAO.addBus(bus);

        verify(session).save(bus);
        verify(transaction).commit();
    }

    @Test
    public void testDeleteBus() {
        Bus bus = new Bus("NB125", "PLATE125", "TypeC", "Owner3", "inactive");

        // No return value needed for session.delete
        doNothing().when(session).delete(bus);

        busDAO.deleteBus(bus);

        verify(session).delete(bus);
        verify(transaction).commit();
    }

    @Test
    public void testUpdateBus() {
        Bus bus = new Bus("NB126", "PLATE126", "TypeD", "Owner4", "depot");
        bus.setIdBus(1); // Ensure the bus has an ID for testing update

        // No return value needed for session.update
        doNothing().when(session).update(bus);

        busDAO.updateBus(bus);

        verify(session).update(bus);
        verify(transaction).commit();
    }

    @Test
    public void testGetAvailableBuses() {
        Bus bus = new Bus("NB127", "PLATE127", "TypeE", "Owner5", "depot");

        when(query.list()).thenReturn(Collections.singletonList(bus));

        List<Bus> availableBuses = busDAO.getAvailableBuses();

        assertNotNull(availableBuses);
        assertEquals(1, availableBuses.size());
        assertEquals("NB127", availableBuses.get(0).getNoBody());
        assertEquals("PLATE127", availableBuses.get(0).getPlatNomor());
        assertEquals("depot", availableBuses.get(0).getStatus());
    }

    @Test
    public void testFindById() {
        Bus bus = new Bus("NB128", "PLATE128", "TypeF", "Owner6", "depot");
        bus.setIdBus(1);

        // Mock session.get to return the bus
        when(session.get(Bus.class, 1)).thenReturn(bus);

        Bus result = busDAO.findById(1);

        assertNotNull(result);
        assertEquals(Integer.valueOf(1), result.getIdBus());
        assertEquals("NB128", result.getNoBody());
        assertEquals("PLATE128", result.getPlatNomor());
    }
}
